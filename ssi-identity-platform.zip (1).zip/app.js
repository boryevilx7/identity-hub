// IdentityBridge SSI Platform - Robust Fixed Version

class IdentityBridge {
    constructor() {
        this.currentUser = null;
        this.currentStep = 1;
        this.maxStep = 5;
        this.onboardingData = {};
        this.credentials = [];
        this.verificationRequests = [];
        this.isInitialized = false;
    }

    async init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            await new Promise(resolve => {
                document.addEventListener('DOMContentLoaded', resolve);
            });
        }
        
        console.log('Initializing IdentityBridge...');
        
        // Ensure all elements exist before setting up
        this.waitForElements().then(() => {
            this.setupEventListeners();
            this.loadSampleData();
            this.isInitialized = true;
            console.log('IdentityBridge initialized successfully');
        });
    }

    waitForElements() {
        return new Promise((resolve) => {
            const checkElements = () => {
                const requiredElements = [
                    'getStartedBtn',
                    'viewDemoBtn',
                    'step1Next'
                ];
                
                const allExist = requiredElements.every(id => document.getElementById(id));
                
                if (allExist) {
                    resolve();
                } else {
                    setTimeout(checkElements, 100);
                }
            };
            checkElements();
        });
    }

    setupEventListeners() {
        console.log('Setting up event listeners...');
        
        // Primary navigation buttons
        this.addClickListener('getStartedBtn', () => {
            console.log('Get Started button clicked');
            this.startOnboarding();
        });

        this.addClickListener('viewDemoBtn', () => {
            console.log('View Demo button clicked');
            this.viewDemo();
        });

        // Theme toggle
        this.addClickListener('themeToggle', () => {
            this.toggleTheme();
        });

        // Language select
        const languageSelect = document.getElementById('languageSelect');
        if (languageSelect) {
            languageSelect.addEventListener('change', (e) => {
                this.changeLanguage(e.target.value);
            });
        }

        // Onboarding step buttons
        this.addClickListener('step1Next', () => {
            console.log('Step 1 Next button clicked');
            this.validateStep1();
        });

        this.addClickListener('step2Next', () => {
            console.log('Step 2 Next button clicked');
            this.nextStep();
        });

        this.addClickListener('step3Next', () => {
            console.log('Step 3 Next button clicked');
            this.nextStep();
        });

        this.addClickListener('step4Next', () => {
            console.log('Step 4 Next button clicked');
            this.nextStep();
        });

        this.addClickListener('completeOnboarding', () => {
            console.log('Complete Onboarding button clicked');
            this.completeOnboarding();
        });

        // Biometric capture buttons
        this.addClickListener('faceScanBtn', () => {
            this.captureBiometric('face');
        });

        this.addClickListener('fingerprintBtn', () => {
            this.captureBiometric('fingerprint');
        });

        // Document upload handlers
        const idDocument = document.getElementById('idDocument');
        const proofDocument = document.getElementById('proofDocument');
        
        if (idDocument) {
            idDocument.addEventListener('change', (e) => this.handleDocumentUpload(e, 'id'));
        }
        if (proofDocument) {
            proofDocument.addEventListener('change', (e) => this.handleDocumentUpload(e, 'proof'));
        }

        // Recovery phrase confirmation
        const recoveryConfirm = document.getElementById('recoveryConfirm');
        if (recoveryConfirm) {
            recoveryConfirm.addEventListener('change', (e) => {
                const completeBtn = document.getElementById('completeOnboarding');
                if (completeBtn) {
                    completeBtn.disabled = !e.target.checked;
                }
            });
        }

        // Dashboard navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const tabName = item.getAttribute('data-tab');
                console.log('Tab clicked:', tabName);
                if (tabName) {
                    this.switchTab(tabName);
                }
            });
        });

        // Dashboard action buttons
        this.addClickListener('shareIdentityBtn', () => {
            this.openShareModal();
        });

        this.addClickListener('addCredentialBtn', () => {
            this.addCredential();
        });

        // Modal controls
        this.addClickListener('shareModalClose', () => {
            this.closeShareModal();
        });

        this.addClickListener('shareModalOverlay', () => {
            this.closeShareModal();
        });

        // Form validation setup
        this.setupFormValidation();
        
        console.log('Event listeners set up complete');
    }

    addClickListener(elementId, handler) {
        const element = document.getElementById(elementId);
        if (element) {
            element.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                handler();
            });
            console.log(`Event listener added for ${elementId}`);
        } else {
            console.warn(`Element not found: ${elementId}`);
        }
    }

    setupFormValidation() {
        const step1Inputs = ['fullName', 'location', 'occupation', 'phoneNumber'];
        
        step1Inputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.addEventListener('input', () => {
                    this.clearError(input);
                });
                input.addEventListener('blur', () => {
                    this.validateInput(input);
                });
            }
        });
    }

    validateInput(input) {
        const value = input.value.trim();
        const errorEl = document.getElementById(input.id + 'Error');
        
        if (!value) {
            this.showError(input, errorEl, 'This field is required');
            return false;
        }

        if (input.id === 'phoneNumber' && !this.isValidPhone(value)) {
            this.showError(input, errorEl, 'Please enter a valid phone number');
            return false;
        }

        this.clearError(input);
        return true;
    }

    showError(input, errorEl, message) {
        input.style.borderColor = 'var(--color-error)';
        if (errorEl) {
            errorEl.textContent = message;
            errorEl.classList.add('visible');
        }
    }

    clearError(input) {
        input.style.borderColor = '';
        const errorEl = document.getElementById(input.id + 'Error');
        if (errorEl) {
            errorEl.classList.remove('visible');
        }
    }

    isValidPhone(phone) {
        const phoneRegex = /^[\+]?[\s\-\(\)]*([0-9][\s\-\(\)]*){10,}$/;
        return phoneRegex.test(phone);
    }

    toggleTheme() {
        const current = document.documentElement.getAttribute('data-color-scheme');
        const newTheme = current === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-color-scheme', newTheme);
        this.updateThemeIcon(newTheme);
        this.showToast('Theme updated');
    }

    updateThemeIcon(theme) {
        const icon = document.querySelector('#themeToggle i');
        if (icon) {
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    changeLanguage(lang) {
        console.log('Language changed to:', lang);
        this.showToast('Language updated successfully');
    }

    startOnboarding() {
        console.log('Starting onboarding process...');
        
        // Hide landing page
        const landingPage = document.getElementById('landingPage');
        if (landingPage) {
            landingPage.classList.add('hidden');
        }
        
        // Show onboarding section
        const onboardingSection = document.getElementById('onboardingSection');
        if (onboardingSection) {
            onboardingSection.classList.remove('hidden');
        }
        
        // Reset to step 1
        this.currentStep = 1;
        this.updateProgress();
        
        // Show step 1
        const step1 = document.getElementById('step1');
        if (step1) {
            step1.classList.add('active');
        }
        
        this.showToast('Welcome to IdentityBridge!');
        console.log('Onboarding started successfully');
    }

    viewDemo() {
        console.log('Loading demo mode...');
        
        // Load demo user data
        this.loadDemoUser();
        
        // Hide landing page
        const landingPage = document.getElementById('landingPage');
        if (landingPage) {
            landingPage.classList.add('hidden');
        }
        
        // Show dashboard
        const dashboardSection = document.getElementById('dashboardSection');
        if (dashboardSection) {
            dashboardSection.classList.remove('hidden');
        }
        
        // Switch to identity tab
        this.switchTab('identity');
        this.showToast('Demo mode activated');
        console.log('Demo mode loaded successfully');
    }

    loadDemoUser() {
        this.currentUser = {
            id: this.generateUserId(),
            name: "Maria Gonzales",
            location: "Guatemala",
            occupation: "Small business owner",
            phone: "+502-1234-5678",
            verificationScore: 96,
            securityLevel: 'High',
            lastUsed: 'Today',
            createdAt: new Date().toISOString()
        };
        
        this.loadUserCredentials();
        this.loadVerificationRequests();
        this.updateDashboardUI();
    }

    validateStep1() {
        console.log('Validating Step 1...');
        
        const fullName = document.getElementById('fullName');
        const location = document.getElementById('location');
        const occupation = document.getElementById('occupation');
        const phoneNumber = document.getElementById('phoneNumber');
        
        let isValid = true;
        const errors = [];
        
        if (!fullName || !fullName.value.trim()) {
            isValid = false;
            errors.push('Full name is required');
            if (fullName) {
                this.showError(fullName, document.getElementById('fullNameError'), 'Full name is required');
            }
        }
        
        if (!location || !location.value.trim()) {
            isValid = false;
            errors.push('Location is required');
        }
        
        if (!occupation || !occupation.value.trim()) {
            isValid = false;
            errors.push('Occupation is required');
        }
        
        if (!phoneNumber || !phoneNumber.value.trim()) {
            isValid = false;
            errors.push('Phone number is required');
        }
        
        if (isValid) {
            // Save form data
            this.onboardingData.personalInfo = {
                fullName: fullName.value.trim(),
                location: location.value.trim(),
                occupation: occupation.value.trim(),
                phoneNumber: phoneNumber.value.trim()
            };
            
            console.log('Step 1 validation passed, moving to step 2');
            this.nextStep();
        } else {
            console.log('Step 1 validation failed:', errors);
            this.showToast('Please fill in all required fields', 'error');
        }
    }

    nextStep() {
        if (this.currentStep >= this.maxStep) {
            console.log('Already at max step');
            return;
        }
        
        console.log(`Moving from step ${this.currentStep} to step ${this.currentStep + 1}`);
        
        // Hide current step
        const currentStepEl = document.getElementById(`step${this.currentStep}`);
        if (currentStepEl) {
            currentStepEl.classList.remove('active');
        }
        
        // Increment step
        this.currentStep++;
        
        // Show next step
        const nextStepEl = document.getElementById(`step${this.currentStep}`);
        if (nextStepEl) {
            nextStepEl.classList.add('active');
        }
        
        // Update progress
        this.updateProgress();
        
        // Handle special step logic
        if (this.currentStep === 4) {
            this.updateWalletPreview();
        }
        
        if (this.currentStep === 5) {
            this.generateRecoveryPhrase();
        }
        
        console.log(`Successfully moved to step ${this.currentStep}`);
    }

    updateProgress() {
        // Update progress bar
        const progressFill = document.getElementById('progressFill');
        if (progressFill) {
            const progress = (this.currentStep / this.maxStep) * 100;
            progressFill.style.width = `${progress}%`;
        }
        
        // Update step indicators
        const steps = document.querySelectorAll('.progress-steps .step');
        steps.forEach((step, index) => {
            const stepNum = index + 1;
            step.classList.remove('active', 'completed');
            
            if (stepNum < this.currentStep) {
                step.classList.add('completed');
                step.innerHTML = '<i class="fas fa-check"></i>';
            } else if (stepNum === this.currentStep) {
                step.classList.add('active');
                step.textContent = stepNum;
            } else {
                step.textContent = stepNum;
            }
        });
    }

    updateWalletPreview() {
        const walletId = document.getElementById('walletId');
        const walletName = document.getElementById('walletName');
        
        if (walletId) {
            walletId.textContent = this.generateUserId();
        }
        
        if (walletName && this.onboardingData.personalInfo) {
            walletName.textContent = this.onboardingData.personalInfo.fullName;
        }
    }

    generateUserId() {
        const year = new Date().getFullYear();
        const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        return `ID-${year}-${random}`;
    }

    generateRecoveryPhrase() {
        const words = [
            'apple', 'brave', 'cloud', 'dream', 'earth', 'flame',
            'guard', 'heart', 'light', 'magic', 'night', 'ocean'
        ];
        
        const phraseContainer = document.getElementById('recoveryPhrase');
        if (phraseContainer) {
            phraseContainer.innerHTML = '';
            
            words.forEach((word, index) => {
                const wordEl = document.createElement('div');
                wordEl.className = 'recovery-word';
                wordEl.textContent = `${index + 1}. ${word}`;
                phraseContainer.appendChild(wordEl);
            });
        }
    }

    captureBiometric(type) {
        console.log(`Capturing ${type} biometric...`);
        
        const btnId = type === 'face' ? 'faceScanBtn' : 'fingerprintBtn';
        const statusId = type === 'face' ? 'faceStatus' : 'fingerprintStatus';
        
        const btn = document.getElementById(btnId);
        const status = document.getElementById(statusId);
        
        this.showLoading(`Capturing ${type}...`);
        
        setTimeout(() => {
            if (btn) btn.style.display = 'none';
            if (status) status.classList.remove('hidden');
            
            this.hideLoading();
            
            // Check if both biometrics are captured
            const faceStatus = document.getElementById('faceStatus');
            const fingerprintStatus = document.getElementById('fingerprintStatus');
            
            if (faceStatus && fingerprintStatus && 
                !faceStatus.classList.contains('hidden') && 
                !fingerprintStatus.classList.contains('hidden')) {
                
                const step2Next = document.getElementById('step2Next');
                if (step2Next) {
                    step2Next.classList.remove('hidden');
                }
            }
            
            this.showToast(`${type} captured successfully`);
        }, 2000);
    }

    handleDocumentUpload(event, type) {
        const file = event.target.files[0];
        if (!file) return;
        
        console.log(`Processing ${type} document upload:`, file.name);
        
        const statusId = `${type}DocStatus`;
        const statusEl = document.getElementById(statusId);
        const uploadArea = event.target.closest('.upload-item').querySelector('.upload-area');
        
        this.showLoading('Verifying document...');
        
        setTimeout(() => {
            if (statusEl) {
                statusEl.innerHTML = '<span class="status status--success"><i class="fas fa-check"></i> Verified</span>';
            }
            
            if (uploadArea) {
                uploadArea.classList.add('uploaded');
            }
            
            this.hideLoading();
            
            // Check if both documents are uploaded
            const idStatus = document.getElementById('idDocStatus');
            const proofStatus = document.getElementById('proofDocStatus');
            
            if (idStatus && proofStatus && idStatus.innerHTML && proofStatus.innerHTML) {
                const step3Next = document.getElementById('step3Next');
                if (step3Next) {
                    step3Next.classList.remove('hidden');
                }
            }
            
            this.showToast('Document verified successfully');
        }, 2500);
    }

    completeOnboarding() {
        console.log('Completing onboarding...');
        
        this.showLoading('Creating your digital identity...');
        
        // Create user from onboarding data
        this.currentUser = {
            id: this.generateUserId(),
            name: this.onboardingData.personalInfo?.fullName || 'Demo User',
            location: this.onboardingData.personalInfo?.location || 'Demo Location', 
            occupation: this.onboardingData.personalInfo?.occupation || 'Demo Occupation',
            phone: this.onboardingData.personalInfo?.phoneNumber || '+1234567890',
            verificationScore: 96,
            securityLevel: 'High',
            lastUsed: 'Just now',
            createdAt: new Date().toISOString()
        };
        
        setTimeout(() => {
            this.hideLoading();
            
            // Hide onboarding
            const onboardingSection = document.getElementById('onboardingSection');
            if (onboardingSection) {
                onboardingSection.classList.add('hidden');
            }
            
            // Show dashboard
            const dashboardSection = document.getElementById('dashboardSection');
            if (dashboardSection) {
                dashboardSection.classList.remove('hidden');
            }
            
            // Load dashboard data
            this.loadUserCredentials();
            this.loadVerificationRequests();
            this.updateDashboardUI();
            
            // Switch to identity tab
            this.switchTab('identity');
            
            this.showToast('Identity created successfully!');
            console.log('Onboarding completed successfully');
        }, 3000);
    }

    loadUserCredentials() {
        this.credentials = [
            {
                id: 'cred_1',
                name: 'Digital Identity',
                issuer: 'IdentityBridge',
                date: new Date().toISOString().split('T')[0],
                icon: 'fas fa-id-card',
                status: 'verified'
            },
            {
                id: 'cred_2',
                name: 'Phone Verification',
                issuer: 'Telecom Provider',
                date: new Date().toISOString().split('T')[0],
                icon: 'fas fa-phone',
                status: 'verified'
            },
            {
                id: 'cred_3',
                name: 'Biometric Verification',
                issuer: 'IdentityBridge',
                date: new Date().toISOString().split('T')[0],
                icon: 'fas fa-fingerprint',
                status: 'verified'
            }
        ];
    }

    loadVerificationRequests() {
        this.verificationRequests = [
            {
                id: 'req_1',
                requester: 'MicroFinance Bank',
                purpose: 'Loan Application',
                requestedData: ['Name', 'Identity Verification', 'Location'],
                time: '2 hours ago',
                status: 'pending'
            },
            {
                id: 'req_2',
                requester: 'Digital Wallet Service',
                purpose: 'Account Opening',
                requestedData: ['Name', 'Phone Verification'],
                time: '1 day ago',
                status: 'pending'
            },
            {
                id: 'req_3',
                requester: 'Government Services',
                purpose: 'Social Program Enrollment',
                requestedData: ['Identity Verification', 'Location'],
                time: '3 days ago',
                status: 'approved'
            }
        ];
    }

    loadSampleData() {
        // Sample data is already loaded in other methods
        console.log('Sample data loaded');
    }

    updateDashboardUI() {
        if (!this.currentUser) {
            console.log('No current user, cannot update dashboard UI');
            return;
        }
        
        console.log('Updating dashboard UI...');
        
        // Update sidebar user info
        const dashboardUserName = document.getElementById('dashboardUserName');
        const dashboardUserLocation = document.getElementById('dashboardUserLocation');
        
        if (dashboardUserName) dashboardUserName.textContent = this.currentUser.name;
        if (dashboardUserLocation) dashboardUserLocation.textContent = this.currentUser.location;
        
        // Update identity card
        const idCardName = document.getElementById('idCardName');
        const idCardLocation = document.getElementById('idCardLocation');
        const idCardOccupation = document.getElementById('idCardOccupation');
        const idCardNumber = document.getElementById('idCardNumber');
        
        if (idCardName) idCardName.textContent = this.currentUser.name;
        if (idCardLocation) idCardLocation.textContent = this.currentUser.location;
        if (idCardOccupation) idCardOccupation.textContent = this.currentUser.occupation;
        if (idCardNumber) idCardNumber.textContent = this.currentUser.id;
        
        // Generate QR codes
        this.generateIdentityQR();
        
        // Render dynamic content
        this.renderCredentials();
        this.renderVerificationRequests();
        
        console.log('Dashboard UI updated successfully');
    }

    switchTab(tabName) {
        console.log('Switching to tab:', tabName);
        
        // Remove active states
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        // Add active states
        const navItem = document.querySelector(`[data-tab="${tabName}"]`);
        const tabContent = document.getElementById(`${tabName}Tab`);
        
        if (navItem) navItem.classList.add('active');
        if (tabContent) tabContent.classList.add('active');
        
        // Load tab-specific content
        if (tabName === 'analytics') {
            setTimeout(() => this.initializeAnalytics(), 200);
        }
        
        console.log(`Switched to tab: ${tabName}`);
    }

    renderCredentials() {
        const container = document.getElementById('credentialsGrid');
        if (!container || !this.credentials) return;
        
        container.innerHTML = this.credentials.map(cred => `
            <div class="credential-card">
                <div class="credential-header">
                    <div class="credential-icon">
                        <i class="${cred.icon}"></i>
                    </div>
                    <div class="status status--${cred.status === 'verified' ? 'success' : 'warning'}">
                        ${cred.status}
                    </div>
                </div>
                <div class="credential-content">
                    <h4>${cred.name}</h4>
                    <p class="credential-issuer">Issued by ${cred.issuer}</p>
                    <p class="credential-date">Date: ${new Date(cred.date).toLocaleDateString()}</p>
                </div>
            </div>
        `).join('');
    }

    renderVerificationRequests() {
        const container = document.getElementById('verificationRequests');
        if (!container || !this.verificationRequests) return;
        
        container.innerHTML = this.verificationRequests.map(req => `
            <div class="verification-request">
                <div class="request-info">
                    <h4>${req.requester}</h4>
                    <p class="request-details">Purpose: ${req.purpose}</p>
                    <p class="request-details">Requested: ${req.requestedData.join(', ')}</p>
                    <p class="request-time">${req.time}</p>
                </div>
                <div class="request-actions">
                    ${req.status === 'pending' ? `
                        <button class="btn btn--primary btn--sm" onclick="app.approveRequest('${req.id}')">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button class="btn btn--outline btn--sm" onclick="app.denyRequest('${req.id}')">
                            <i class="fas fa-times"></i> Deny
                        </button>
                    ` : `
                        <span class="status status--${req.status === 'approved' ? 'success' : 'error'}">
                            ${req.status}
                        </span>
                    `}
                </div>
            </div>
        `).join('');
    }

    generateIdentityQR() {
        const canvas = document.getElementById('identityQR');
        if (!canvas || !this.currentUser) return;
        
        if (typeof QRCode !== 'undefined') {
            const identityData = {
                id: this.currentUser.id,
                name: this.currentUser.name,
                verified: true,
                timestamp: Date.now()
            };
            
            QRCode.toCanvas(canvas, JSON.stringify(identityData), {
                width: 150,
                margin: 2,
                color: {
                    dark: '#218089',
                    light: '#FFFFFF'
                }
            }).catch(err => {
                console.log('QR generation failed, using fallback');
                this.drawFallbackQR(canvas, 150);
            });
        } else {
            this.drawFallbackQR(canvas, 150);
        }
    }

    drawFallbackQR(canvas, size) {
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#218089';
        ctx.fillRect(0, 0, size, size);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('QR Code', size/2, size/2);
    }

    initializeAnalytics() {
        console.log('Initializing analytics...');
        setTimeout(() => {
            this.createGlobalImpactChart();
        }, 300);
    }

    createGlobalImpactChart() {
        const canvas = document.getElementById('globalImpactChart');
        if (!canvas) {
            console.log('Analytics canvas not found');
            return;
        }
        
        if (typeof Chart !== 'undefined') {
            const ctx = canvas.getContext('2d');
            
            // Destroy existing chart
            if (this.globalChart) {
                this.globalChart.destroy();
            }
            
            this.globalChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Banked Population', 'Unbanked Population', 'SSI Enabled'],
                    datasets: [{
                        data: [83, 17, 8.5],
                        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        }
                    }
                }
            });
        } else {
            console.log('Chart.js not available, showing fallback');
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = '#1FB8CD';
            ctx.fillRect(0, 0, 300, 200);
            ctx.fillStyle = '#FFFFFF';
            ctx.font = '16px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('Analytics Chart', 150, 100);
        }
    }

    approveRequest(requestId) {
        const request = this.verificationRequests.find(req => req.id === requestId);
        if (request) {
            request.status = 'approved';
            this.renderVerificationRequests();
            this.showToast('Verification request approved');
        }
    }

    denyRequest(requestId) {
        const request = this.verificationRequests.find(req => req.id === requestId);
        if (request) {
            request.status = 'denied';
            this.renderVerificationRequests();
            this.showToast('Verification request denied');
        }
    }

    addCredential() {
        const newCredential = {
            id: `cred_${Date.now()}`,
            name: 'Business License',
            issuer: 'Chamber of Commerce',
            date: new Date().toISOString().split('T')[0],
            icon: 'fas fa-briefcase',
            status: 'pending'
        };
        
        this.credentials.push(newCredential);
        this.renderCredentials();
        this.showToast('Credential added successfully');
    }

    openShareModal() {
        const modal = document.getElementById('shareModal');
        if (modal) {
            modal.classList.remove('hidden');
            this.generateShareQR();
        }
    }

    closeShareModal() {
        const modal = document.getElementById('shareModal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    generateShareQR() {
        const canvas = document.getElementById('shareQR');
        if (!canvas || !this.currentUser) return;
        
        if (typeof QRCode !== 'undefined') {
            const shareData = {
                id: this.currentUser.id,
                name: this.currentUser.name,
                verified: true,
                shared_at: Date.now()
            };
            
            QRCode.toCanvas(canvas, JSON.stringify(shareData), {
                width: 200,
                margin: 2,
                color: {
                    dark: '#218089',
                    light: '#FFFFFF'
                }
            }).catch(() => {
                this.drawFallbackQR(canvas, 200);
            });
        } else {
            this.drawFallbackQR(canvas, 200);
        }
    }

    showLoading(message = 'Loading...') {
        const overlay = document.getElementById('loadingOverlay');
        const text = document.getElementById('loadingText');
        
        if (overlay && text) {
            text.textContent = message;
            overlay.classList.remove('hidden');
        }
    }

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('hidden');
        }
    }

    showToast(message, type = 'success') {
        const toast = document.getElementById('successToast');
        const messageEl = document.getElementById('toastMessage');
        
        if (toast && messageEl) {
            messageEl.textContent = message;
            toast.classList.remove('hidden');
            
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 3000);
        }
    }
}

// Global app instance
let app = null;

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

function initializeApp() {
    console.log('DOM ready, initializing app...');
    app = new IdentityBridge();
    app.init();
}

// Global error handling
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    if (app) {
        app.hideLoading();
        app.showToast('An error occurred. Please try again.', 'error');
    }
});

// Keyboard accessibility
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        if (app) {
            app.closeShareModal();
        }
    }
});